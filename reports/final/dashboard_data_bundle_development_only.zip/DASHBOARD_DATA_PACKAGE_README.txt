RiverDemand dashboard data package

Extract this archive at the repository root. It contains only processed development data and saved dashboard artifacts; it contains no raw M5 inputs and no final-holdout target values. Verify file hashes using dashboard_data_manifest.json.
