RiverDemand dashboard data package

Extract this archive at the repository root. It contains processed development data, saved dashboard artifacts, and when present, compact final-holdout summary metrics and the evaluation record. It contains no raw M5 inputs or row-level final-holdout forecasts. Verify file hashes using dashboard_data_manifest.json.
